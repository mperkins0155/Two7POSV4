from core.database import Base
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String


class Modifier_options(Base):
    __tablename__ = "modifier_options"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    modifier_group_id = Column(Integer, nullable=False)
    name = Column(String, nullable=False)
    price_adjustment = Column(Float, nullable=True, default=0, server_default='0')
    is_active = Column(Boolean, nullable=True, default=True, server_default='true')
    sort_order = Column(Integer, nullable=True, default=0, server_default='0')
    created_at = Column(DateTime(timezone=True), nullable=True)