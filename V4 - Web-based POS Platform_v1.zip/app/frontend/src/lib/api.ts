import { createClient } from '@metagptx/web-sdk';

// Create client instance
export const client = createClient();
